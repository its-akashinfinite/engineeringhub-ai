"""
EngineerHub AI — Signal Processing Workspace Backend
------------------------------------------------------
FastAPI service exposing a spectral-subtraction based denoising pipeline
for uploaded .wav audio, mirroring a MATLAB-style DSP voice de-noising flow.

Run locally:
    uvicorn main:app --reload --port 8000

See README.md in this directory for full setup + Vercel deployment notes.
"""

import base64
import io
import time
import uuid
from typing import Tuple

import numpy as np
import soundfile as sf
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from scipy.signal import istft, stft

# --------------------------------------------------------------------------
# App configuration
# --------------------------------------------------------------------------

app = FastAPI(
    title="EngineerHub AI — Signal Processing Workspace API",
    description="Spectral subtraction denoising service for uploaded audio buffers.",
    version="1.0.0",
)

# Restrict this list to your actual Vercel frontend domain(s) in production.
ALLOWED_ORIGINS = [
    "http://localhost:5173",
    "https://your-engineerhub-app.vercel.app",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["POST"],
    allow_headers=["*"],
)

# --------------------------------------------------------------------------
# Constants
# --------------------------------------------------------------------------

MAX_FILE_SIZE_BYTES = 25 * 1024 * 1024  # 25 MB upload ceiling
ALLOWED_CONTENT_TYPES = {"audio/wav", "audio/x-wav", "audio/wave"}
STFT_WINDOW = "hann"
STFT_NPERSEG = 1024          # frame size for STFT analysis
STFT_NOVERLAP = 768          # 75% overlap between frames
NOISE_ESTIMATE_FRAMES = 6    # number of leading frames assumed to be "noise only"
WAVEFORM_PREVIEW_POINTS = 800  # downsampled points returned for the frontend visualizer


# --------------------------------------------------------------------------
# Response models
# --------------------------------------------------------------------------

class ProcessMetadata(BaseModel):
    job_id: str
    sample_rate: int
    duration_seconds: float
    channels: int
    threshold_percentage: float
    noise_floor_db: float
    average_attenuation_db: float
    processing_time_ms: float


class ProcessAudioResponse(BaseModel):
    metadata: ProcessMetadata
    original_waveform: list[float]
    processed_waveform: list[float]
    processed_audio_base64: str
    audio_mime_type: str = "audio/wav"


# --------------------------------------------------------------------------
# DSP core — spectral subtraction
# --------------------------------------------------------------------------

def spectral_subtraction_denoise(
    audio: np.ndarray,
    sample_rate: int,
    threshold_percentage: float,
) -> Tuple[np.ndarray, float, float]:
    """
    Attenuates stationary background noise from a mono audio buffer using
    magnitude-domain spectral subtraction — the same principle behind classic
    MATLAB de-noising scripts (specgram -> subtract noise magnitude -> reconstruct).

    Steps:
      1. STFT the signal into the time-frequency domain.
      2. Estimate the noise magnitude spectrum from the first few frames
         (assumed silence/ambient noise, a common convention in voice capture).
      3. Subtract a scaled version of that noise estimate from every frame's
         magnitude, scaled by `threshold_percentage` (0–100) from the frontend.
      4. Floor any over-subtracted bins (to avoid musical noise / negative energy).
      5. Reconstruct the time-domain signal via inverse STFT using the
         original phase (standard spectral subtraction assumption).

    Args:
        audio: 1-D float32 mono waveform, normalized to [-1, 1].
        sample_rate: audio sample rate in Hz.
        threshold_percentage: 0-100 aggressiveness of the noise subtraction,
            supplied dynamically by the frontend slider/control.

    Returns:
        (denoised_audio, noise_floor_db, average_attenuation_db)
    """
    if audio.ndim != 1:
        raise ValueError("spectral_subtraction_denoise expects a mono 1-D buffer")

    # Clamp to a sane 0-100 range regardless of what the client sends
    threshold_percentage = float(np.clip(threshold_percentage, 0.0, 100.0))
    subtraction_factor = threshold_percentage / 100.0

    # --- 1. Forward STFT ---
    freqs, frames, Zxx = stft(
        audio,
        fs=sample_rate,
        window=STFT_WINDOW,
        nperseg=STFT_NPERSEG,
        noverlap=STFT_NOVERLAP,
    )

    magnitude = np.abs(Zxx)
    phase = np.angle(Zxx)

    # --- 2. Noise magnitude estimate from leading frames ---
    frame_count = magnitude.shape[1]
    noise_frames = min(NOISE_ESTIMATE_FRAMES, max(1, frame_count // 4))
    noise_estimate = np.mean(magnitude[:, :noise_frames], axis=1, keepdims=True)

    noise_floor_db = float(20 * np.log10(np.mean(noise_estimate) + 1e-10))

    # --- 3. Subtract scaled noise estimate from every frame ---
    subtracted_magnitude = magnitude - (subtraction_factor * noise_estimate)

    # --- 4. Spectral floor to prevent negative-energy artifacts ("musical noise") ---
    spectral_floor = 0.02 * magnitude
    clean_magnitude = np.maximum(subtracted_magnitude, spectral_floor)

    average_attenuation_db = float(
        20 * np.log10((np.mean(magnitude) + 1e-10) / (np.mean(clean_magnitude) + 1e-10))
    )

    # --- 5. Reconstruct using original phase ---
    clean_complex = clean_magnitude * np.exp(1j * phase)
    _, denoised_audio = istft(
        clean_complex,
        fs=sample_rate,
        window=STFT_WINDOW,
        nperseg=STFT_NPERSEG,
        noverlap=STFT_NOVERLAP,
    )

    # Trim/pad to match original buffer length (ISTFT can shift length slightly)
    if len(denoised_audio) > len(audio):
        denoised_audio = denoised_audio[: len(audio)]
    else:
        denoised_audio = np.pad(denoised_audio, (0, len(audio) - len(denoised_audio)))

    # Guard against clipping after reconstruction
    peak = np.max(np.abs(denoised_audio)) + 1e-10
    if peak > 1.0:
        denoised_audio = denoised_audio / peak

    return denoised_audio.astype(np.float32), noise_floor_db, average_attenuation_db


def downsample_for_visualizer(audio: np.ndarray, target_points: int) -> list:
    """
    Reduces a waveform buffer to a fixed number of representative points
    (via simple block-max sampling) so the frontend visualizer can render
    a waveform without shipping the full sample array over JSON.
    """
    if len(audio) <= target_points:
        return audio.tolist()

    block_size = len(audio) // target_points
    trimmed_length = block_size * target_points
    reshaped = audio[:trimmed_length].reshape(target_points, block_size)

    # Block-max on absolute value preserves peaks better than a plain mean,
    # which matters for a de-noising visualizer where peaks are the story.
    peak_indices = np.argmax(np.abs(reshaped), axis=1)
    peak_values = reshaped[np.arange(target_points), peak_indices]

    return np.round(peak_values, 5).tolist()


# --------------------------------------------------------------------------
# Endpoint
# --------------------------------------------------------------------------

@app.post("/api/process-audio", response_model=ProcessAudioResponse)
async def process_audio(
    file: UploadFile = File(..., description="Raw .wav audio file to denoise"),
    threshold_percentage: float = Form(
        50.0, description="Noise subtraction aggressiveness, 0-100"
    ),
):
    """
    Accepts a .wav upload plus a dynamic threshold percentage, runs spectral
    subtraction denoising, and returns processed audio (base64) alongside
    metadata and downsampled waveform arrays for the frontend visualizer.
    """
    start_time = time.perf_counter()

    # --- Validate content type up front ---
    if file.content_type not in ALLOWED_CONTENT_TYPES:
        raise HTTPException(
            status_code=415,
            detail=f"Unsupported file type '{file.content_type}'. Only .wav is accepted.",
        )

    # --- Read + size-guard the upload ---
    raw_bytes = await file.read()
    if not raw_bytes:
        raise HTTPException(status_code=400, detail="Uploaded file is empty.")
    if len(raw_bytes) > MAX_FILE_SIZE_BYTES:
        raise HTTPException(
            status_code=413,
            detail=f"File exceeds the {MAX_FILE_SIZE_BYTES // (1024 * 1024)}MB limit.",
        )

    # --- Decode the WAV buffer safely ---
    try:
        audio_data, sample_rate = sf.read(io.BytesIO(raw_bytes), dtype="float32")
    except Exception as exc:
        raise HTTPException(
            status_code=400,
            detail=f"Could not decode audio — file may be corrupted or not a valid WAV. ({exc})",
        ) from exc

    # --- Normalize to mono for a single clean DSP pipeline ---
    channels = 1
    if audio_data.ndim > 1:
        channels = audio_data.shape[1]
        audio_data = np.mean(audio_data, axis=1)

    if len(audio_data) < STFT_NPERSEG:
        raise HTTPException(
            status_code=422,
            detail="Audio clip is too short to process (must exceed one STFT frame).",
        )

    # --- Run the DSP pipeline ---
    try:
        denoised_audio, noise_floor_db, avg_attenuation_db = spectral_subtraction_denoise(
            audio=audio_data,
            sample_rate=sample_rate,
            threshold_percentage=threshold_percentage,
        )
    except Exception as exc:
        raise HTTPException(
            status_code=500, detail=f"DSP processing failed: {exc}"
        ) from exc

    # --- Encode processed audio back to WAV bytes, then base64 for JSON transport ---
    output_buffer = io.BytesIO()
    sf.write(output_buffer, denoised_audio, sample_rate, format="WAV", subtype="PCM_16")
    processed_audio_base64 = base64.b64encode(output_buffer.getvalue()).decode("utf-8")

    processing_time_ms = round((time.perf_counter() - start_time) * 1000, 2)

    metadata = ProcessMetadata(
        job_id=str(uuid.uuid4()),
        sample_rate=sample_rate,
        duration_seconds=round(len(audio_data) / sample_rate, 3),
        channels=channels,
        threshold_percentage=threshold_percentage,
        noise_floor_db=round(noise_floor_db, 2),
        average_attenuation_db=round(avg_attenuation_db, 2),
        processing_time_ms=processing_time_ms,
    )

    return ProcessAudioResponse(
        metadata=metadata,
        original_waveform=downsample_for_visualizer(audio_data, WAVEFORM_PREVIEW_POINTS),
        processed_waveform=downsample_for_visualizer(denoised_audio, WAVEFORM_PREVIEW_POINTS),
        processed_audio_base64=processed_audio_base64,
    )


@app.get("/api/health")
async def health_check():
    """Lightweight endpoint for uptime checks / Vercel function warm-up pings."""
    return {"status": "ok"}
